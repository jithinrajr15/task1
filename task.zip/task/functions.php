<?php



function get_product_title($dom)

{
	
	$title=$dom->getElementById('itemTitle');
	return $title->textContent;
	
	
}

function get_product_title2($dom)

{
	
	$title=$dom->getElementById('itemTitle');
	return $title->textContent;
	
	
}


function get_product_title3($dom)

{
	
	$title=$dom->getElementById('itemTitle');
	return $title->textContent;
	
	
}



function get_product_images($dom)
{
	$images=[];
	$imagesDiv =$dom->getElementById('vi_main_img_fs');
	$links= $imagesDiv->getElementsByTagName("img");
	foreach($links as $link){
		
		$linkHref = $link->getAttribute('src');
		if(!empty($linkHref)){
			
			$images[]=$linkHref;
		}
		
	}
	
	return $images;
	
}


function get_product_images2($dom)
{
	$images2=[];
	$imagesDiv =$dom->getElementById('vi_main_img_fs');
	$links= $imagesDiv->getElementsByTagName("img");
	foreach($links as $link){
		
		$linkHref = $link->getAttribute('src');
		if(!empty($linkHref)){
			
			$images2[]=$linkHref;
		}
		
	}
	
	return $images2;
	
}

function get_product_images3($dom)
{
	$images3=[];
	$imagesDiv =$dom->getElementById('vi_main_img_fs');
	$links= $imagesDiv->getElementsByTagName("img");
	foreach($links as $link){
		
		$linkHref = $link->getAttribute('src');
		if(!empty($linkHref)){
			
			$images3[]=$linkHref;
		}
		
	}
	
	return $images3;
	
}
?>
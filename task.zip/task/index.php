<?php

include 'functions.php';


$images=[];
$images2=[];
$images3=[];
$product=null;
$product2=null;
$product3=null;
$isProductActive = false;
$isProductActive2 = false;
$isProductActive3 = false;
$url="";
$url2="";
$url3="";
$fullpath="";
$fullpath2="";
$fullpath3="";





if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST['parse_link'])){


$url = isset($_POST['url']) ? $_POST['url'] : null;
if($url)
	
	{
		$path="https://www.ebay.com/itm/";
		$fullpath= $path."".$url;
$isProductActive=true;
$html=file_get_contents($fullpath);
$htmlDom = new DOMDocument();
@$htmlDom->loadHTML($html);
$product = get_product_title($htmlDom);
$images = get_product_images($htmlDom);



		
	}
	
	
	
	
	 
}


if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST['parse_link'])){


$url2 = isset($_POST['url2']) ? $_POST['url2'] : null;

	
	
	if($url2)
	
	{
		$path2="https://www.ebay.com/itm/";
		$fullpath2= $path2."".$url2;
$isProductActive2=true;
$html2=file_get_contents($fullpath2);
$htmlDom = new DOMDocument();
@$htmlDom->loadHTML($html2);

$product2 = get_product_title2($htmlDom);
$images2= get_product_images2($htmlDom);


		
	}
	
}


if($_SERVER["REQUEST_METHOD"]=="POST" && isset($_POST['parse_link'])){


$url3 = isset($_POST['url3']) ? $_POST['url3'] : null;

	
	
	if($url3)
	
	{
		$path3="https://www.ebay.com/itm/";
		$fullpath3= $path3."".$url3;
$isProductActive3=true;
$html2=file_get_contents($fullpath3);
$htmlDom = new DOMDocument();
@$htmlDom->loadHTML($html2);

$product3 = get_product_title3($htmlDom);
$images3= get_product_images3($htmlDom);


		
	}
	
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
</head>
<body>
<div class="container">
  <h2>please Enter the Product ID </h2>
  <form method="post">
    <div class="input-group input-group-sm mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text"   id="inputGroup-sizing-sm">Enter ID 1</span>
  </div>
  <input type="text" name="url" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
</div>

  <div class="input-group input-group-sm mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-sm">Enter ID 2</span>
  </div>
  <input type="text" name="url2" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
</div>

  <div class="input-group input-group-sm mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="inputGroup-sizing-sm">Enter ID 3</span>
  </div>
  <input type="text" name="url3"  class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
</div>
    <button type="submit" name="parse_link"  class="btn btn-primary">Submit</button>
  </form>
</div>
<br>
<br>

<div class="table-responsive">
  <table class="table">
    <thead>
      <tr>
        <th scope="col">Product Title</th>
        <th scope="col">Product URL</th>
      
        <th scope="col">Thumbnails</th>
       
      </tr>
    </thead>
    <tbody>
    
  <tr>
   <td><?php if($isProductActive):?>


<?php echo $product;?>


<?php endif;?></td>

<td><a href="<?php echo $fullpath; ?>" name="" value=""><?php echo $fullpath; ?> </a></td>
    <td name="1"><?php foreach ($images as $img):?><input type="radio" name="featuredImg" value="<?php echo $img;?>"/>
<img width="60" height="60" src="<?php echo $img;?>"/>  <?php endforeach; ?></td> 
   
	
  </tr>
  <tr>
   <td><?php if($isProductActive2):?>


<?php echo $product2;?>


<?php endif;?></td>

<td><a href="<?php echo $fullpath2; ?>" name="" value=""><?php echo $fullpath2; ?> </a></td>
    <td name="1"><?php foreach ($images2 as $img2):?><input type="radio" name="featuredImg1" value="<?php echo $img2;?>"/>
<img width="60" height="60" src="<?php echo $img2;?>"/>  <?php endforeach; ?></td> 
   
	
  </tr>
  <tr>
   <td><?php if($isProductActive3):?>


<?php echo $product3;?>


<?php endif;?></td>

<td><a href="<?php echo $fullpath3; ?>" name="" value=""><?php echo $fullpath3; ?> </a></td>
    <td name="1"><?php foreach ($images3 as $img3):?><input type="radio" name="featuredImg1" value="<?php echo $img3;?>"/>
<img width="60" height="60" src="<?php echo $img3;?>"/>  <?php endforeach; ?></td> 
   
	
  </tr>
    </tbody>
  </table>
  
  
 
</div>


</body>
</html>
